# -*- coding: utf-8 -*-

import cv2 #Imports OpenCV for Image processing
import numpy as np #Improts numpy for processing image for HSV values

# A required callback method that goes into the trackbar function.
def Nothing(x):
    pass

# Initializing the webcam feed.
Capture = cv2.VideoCapture(0)
Capture.set(3,1280)
Capture.set(4,720)

# Create a window.
cv2.namedWindow("HSV Values Finder - Trackbars")

# Creating trackbars for upper (U) and lower (L) limit if HSV Values.
cv2.createTrackbar("L - H", #Name of the trackbar
                   "HSV Values Finder - Trackbars", #Name of the window
                   0, #lower limit for range
                   179, #upper limit for range
                   Nothing) #callback function
cv2.createTrackbar("L - S", "HSV Values Finder - Trackbars", 0, 255, Nothing)
cv2.createTrackbar("L - V", "HSV Values Finder - Trackbars", 0, 255, Nothing)
cv2.createTrackbar("U - H", "HSV Values Finder - Trackbars", 179, 179, Nothing)
cv2.createTrackbar("U - S", "HSV Values Finder - Trackbars", 255, 255, Nothing)
cv2.createTrackbar("U - V", "HSV Values Finder - Trackbars", 255, 255, Nothing)
 
#Iterations for finding the HSV from the camera feed frames.
while True:
    
    # Start reading the webcam feed frame by frame.
    Ret_Bool, Frame = Capture.read()
    if not Ret_Bool:
        break
    
    # Flip the frame horizontally (Not required) - for simplicity
    Frame = cv2.flip( Frame, 1 ) 
    
    # Convert the BGR image to HSV image.
    HSV = cv2.cvtColor(Frame, cv2.COLOR_BGR2HSV)
    
    # Get the new values of the trackbar in real time as the user changes them
    l_h = cv2.getTrackbarPos("L - H", "HSV Values Finder - Trackbars")
    l_s = cv2.getTrackbarPos("L - S", "HSV Values Finder - Trackbars")
    l_v = cv2.getTrackbarPos("L - V", "HSV Values Finder - Trackbars")
    u_h = cv2.getTrackbarPos("U - H", "HSV Values Finder - Trackbars")
    u_s = cv2.getTrackbarPos("U - S", "HSV Values Finder - Trackbars")
    u_v = cv2.getTrackbarPos("U - V", "HSV Values Finder - Trackbars")
 
    # Set the lower and upper HSV range according to the value selected by the trackbar
    lower_range = np.array([l_h, l_s, l_v])
    upper_range = np.array([u_h, u_s, u_v])
    
    # Filter the image and get the binary mask, where white represents your target color
    Mask = cv2.inRange(HSV, lower_range, upper_range)
 
    # You can also visualize the real part of the target color - (Optional)
    Res = cv2.bitwise_and(Frame, Frame, mask=Mask)
    
    # Converting the binary mask to 3 channel image, so we can stack it with the others
    Mask_3 = cv2.cvtColor(Mask, cv2.COLOR_GRAY2BGR)
    
    # Stack the mask, orginal frame, and the filtered result
    Stacked = np.hstack((Mask_3,Frame,Res))
    
    # Show this stacked frame at 40% of the size.
    cv2.imshow("HSV Values Finder - Trackbars",cv2.resize(Stacked,None,fx=0.4,fy=0.4))
    
    # If the user presses ESC then exit the program
    key = cv2.waitKey(1)
    if key == 27:
        break
    
    # If the user presses `s` then print this array.
    if key == ord('s'):
        
        thearray = [[l_h,l_s,l_v],[u_h, u_s, u_v]]
        print(thearray)
        break
    
# Release the camera.    
Capture.release()

#Destroy all windows.
cv2.destroyAllWindows()
