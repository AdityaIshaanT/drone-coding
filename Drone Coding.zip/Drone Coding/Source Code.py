# -*- coding: utf-8 -*-
#Final code for implementation

'''Importing the required modules'''

import cv2 #Imports OpenCV for Video processing
import numpy as np #Improts numpy for processing image using HSV values 
from djitellopy import Tello #Imports Tello for connecting to the drone and sending commands
import time #for giving necessary stoppages

'''Defining required functions'''

#Finding the marker object in the array of the frame captured
def Find_Width_Marker_Object(Image_Array):
    
    #converting the image from BGR to HSV
    HSV_Image = cv2.cvtColor(Image_Array, cv2.COLOR_BGR2HSV)  
    
    #defining the HSV colour ranges across which the marker object could be detected
    Lower_Limit_HSV_Values = np.array([17,100,100])
    Upper_Limit_HSV_Values = np.array([30,255,255])
    
    #finding areas in the frame that fall within these variables
    Mask = cv2.inRange(HSV_Image, Lower_Limit_HSV_Values, Upper_Limit_HSV_Values)
    #drawing the cv generated bounding box - (Rect)
    Bounding_Box = cv2.boundingRect(Mask)
    
    #Verifying the existence of bounding box and finding the dimensions
    if Bounding_Box is not None:
        #unpack the values contaning the dimensions and postion (relative to the image borders)
        x,y,width,height = Bounding_Box
        #drawing a rectange around the marker object found
        cv2.rectangle(Image_Array,(x,y),(x+width,y+height),(0,255,0),2)
        #the width so returned is in pixels
        return width
    else:
        return None
    
#Function to find focal length of the DJ Tello camera
def Find_Focal_Length(Measured_Distance, 
                      Ref_Image_Width, 
                      Real_Width):
    #The Ref_Image_Width is in pixels.
    #Measured_Distance and Real_Width are in centimeters.
    #Output for the focal length is in pixels.
    Focal_Length = (Ref_Image_Width * Measured_Distance)/Real_Width
    #The focal length being returned to the function is in pixels.
    return Focal_Length

#Function for computing distance between drone and camera
def Distance_Finder(Focal_Length, 
                    Real_Width, 
                    width):
    Distance = (Real_Width*Focal_Length)/width
    #Real_Width is in CM.
    #Focal_Length and Width are in pixels.
    #Ouput for the distance will be in pixels.
    return Distance

'''Main Code'''

#Unit references - centimeters
#Reference is set for an image at a distance of 100cm
Measured_Distance = 10
#Marker objects so chosen have a width of 3cm
Real_Width = 5

#defining the font for display
Font = cv2.FONT_HERSHEY_COMPLEX

#Converting the reference image into array for processing.
#Argument provided should the path to the marker object.
Read_Image_Array = cv2.imread("C:\\Users\\Abhi\\Desktop\\Marker.jpg")
#Processing the array values using the pre-defined function to get the reference parameters.
Ref_Image_Width = Find_Width_Marker_Object(Read_Image_Array)

#Finding the focal length from references
Focal_Length_Found = Find_Focal_Length(Measured_Distance, Ref_Image_Width, Real_Width)

#Creating the connector and conneting to the drone
Tello_Connector = Tello()
Tello_Connector.connect()
print(Tello_Connector.get_battery())

'''Intializing camera object'''
Tello_Connector.streamon()
time.sleep(1)
#Capture = cv2.VideoCapture(0)

#Looping through each frame from incoming video stream

while True:
    
    '''Capture frame method'''
    #reading the frame from camera - returns - boolean value, numpy array for the frame data
    #RVal, Frame = Capture.read()
    
    '''Tello connector method'''
    #Receving the frame stored in the connection object.
    Frame = Tello_Connector.get_frame_read()
    #Extracting the frame as a numerical array.
    Frame = Frame.frame
    
    #Finding the width of the marker object in pixels
    width = Find_Width_Marker_Object(Frame)
    
    #Evalutating for distance given we know the width has a practical value.
    if width!=0 and width is not None:
        Distance_To_Marker = Distance_Finder(Focal_Length_Found, Real_Width, width)
        
        #Organizing the display
        # draw line as background of text 
        cv2.line(Frame, #the frame on which the line is being drawn
                 (30, 30), #start point of the line
                 (230, 30), #end point of the line
                 (0, 0, 255), #colour of the line
                 32) #thickness of the line
        cv2.line(Frame, 
                 (30, 30), 
                 (230, 30), 
                 (0, 0, 0), 
                 28)
        
        #drawing the text onto the display frame
        cv2.putText(Frame, #image on which display is requried
                    f"Distance: {round(Distance_To_Marker,2)} CM", #display content
                    (30, 35), #postion of display
                    Font, 0.6, # font and scale factor
                    (0, 255, 0), #color of display
                    2) #thickness of text
        
    #Displaying the frame
    #The thirty three milli-second waikey is a result of fps of tello video stream.
    cv2.waitKey(33)
    cv2.imshow("Real-time Distance Tracking",Frame)
    
    #Condition for quitting the program
    if cv2.waitKey(33)==ord("q"):
        break

'''Terminating the image capture - Cpature method'''
#Closing the camera
#Capture.release()

'''Terminating the stream - Tello method'''
Tello_Connector.streamoff()

#Quitting all cv2 windows
cv2.destroyAllWindows()
